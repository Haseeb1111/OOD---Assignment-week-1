package com.lu.observerPattern;

import com.lu.observerPattern.data.PolygonAPI;
import com.lu.observerPattern.impl.LargeCapObserver;
import com.lu.observerPattern.impl.MessagePublisher;
import com.lu.observerPattern.impl.SmallCapObserver;

import java.util.ArrayList;
import java.util.List;

public class Main {

    private final static String POLYGON_IO_API_KEY="YIH2u7pwPicNRMBPBFgV7pwSzDI49MpT";

    public static void main(String[] args) throws InterruptedException {
        PolygonAPI polygonAPI = new PolygonAPI();

        List<String> largeCapCompanies = new ArrayList<>();
        largeCapCompanies.add("AAPL");
        largeCapCompanies.add("GOOGL");

        List<String> smallCapCompanies = new ArrayList<>();
        smallCapCompanies.add("CRC");
        smallCapCompanies.add("GNW");

        System.out.println("Running for large cap companies");
        MessagePublisher largeCapPublisher = new MessagePublisher();
        largeCapPublisher.add(new LargeCapObserver());
        for (String company: largeCapCompanies){
            largeCapPublisher.publish(polygonAPI.getMarketCap(company));
        }

        MessagePublisher smallCapPublisher = new MessagePublisher();
        smallCapPublisher.add(new SmallCapObserver());
        for (String company: smallCapCompanies){
            smallCapPublisher.publish(polygonAPI.getMarketCap(company));
        }
    }
}
