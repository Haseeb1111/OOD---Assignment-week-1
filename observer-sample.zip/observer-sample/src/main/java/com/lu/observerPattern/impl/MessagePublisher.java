package com.lu.observerPattern.impl;

import com.lu.observerPattern.actor.Observer;
import com.lu.observerPattern.actor.Publisher;
import com.lu.observerPattern.data.PolygonAPI;

import java.util.ArrayList;
import java.util.List;

public class MessagePublisher implements Publisher {

    private List<Observer> observers = new ArrayList<>();

    @Override
    public void add(Observer o) {
        observers.add(o);
    }

    @Override
    public void remove(Observer o) {
        observers.remove(o);
    }

    @Override
    public void publish(String m) {
        for(Observer o: observers) {
            o.update(m);
        }
    }
}
