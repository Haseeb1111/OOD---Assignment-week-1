package com.lu.observerPattern.impl;

import com.lu.observerPattern.actor.Observer;

public class LargeCapObserver implements Observer {

    @Override
    public void update(String message) {
        System.out.println("Large Cap Observer :: " + message);
    }
}
