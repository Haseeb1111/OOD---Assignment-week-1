package com.lu.observerPattern.actor;

public interface Publisher {
    public void add(Observer o);
    public void remove(Observer o);
    public void publish(String m);
}
